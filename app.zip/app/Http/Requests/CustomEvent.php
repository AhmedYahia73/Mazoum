<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class CustomEvent extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        switch ($this->method()) {

            case 'GET':
            case 'DELETE':
                return [];

            case 'POST':
                return [
                    'title'   => 'required',
                    'user_id' => 'required',

                    'scan_assistant_id' => 'sometimes|exists:users,id',
                    'assistant_id' => 'sometimes|exists:users,id',
                    'address' => 'required',
                    'date'    => 'required|date|date_format:Y-m-d',
                    'time'    => 'required',

                    'image'   => 'required',
                    'color' => ["sometimes"], 
                    "name_qr" => ["required", "boolean"],
                    "number_qr" => ["required", "boolean"],
                    "qr_height" => ["required", "numeric"],
                    "qr_width" => ["required", "numeric"],
                    "qr_x" => ["required", "numeric"],
                    "qr_y" => ["required", "numeric"],
                    "lat" => ["required", "numeric"],
                    "lng" => ["required", "numeric"],
                    "send_type" => ["required", "in:all,watts,msg"],
                    'image_height' => ['required'],
                    'image_width' => ['required'],
                    'text_color' => ['required'],
                ];

            case 'PUT':
            case 'PATCH':
                return [
                    'title'   => 'required',
                    'user_id' => 'required',

                    'scan_assistant_id' => 'sometimes|exists:users,id',
                    'assistant_id' => 'sometimes|exists:users,id',
                    'address' => 'required',
                    'date'    => 'required|date|date_format:Y-m-d',
                    'time'    => 'required',

                    'image'   => 'nullable',
                    
                    'color' => ["sometimes"], 
                    "name_qr" => ["required", "boolean"],
                    "number_qr" => ["required", "boolean"],
                    "qr_height" => ["required", "numeric"],
                    "qr_width" => ["required", "numeric"],
                    "qr_x" => ["required", "numeric"],
                    "qr_y" => ["required", "numeric"],
                    "lat" => ["required", "numeric"],
                    "lng" => ["required", "numeric"],
                    "send_type" => ["required", "in:all,watts,msg"],
                    'image_height' => ['required', 'numeric'],
                    'image_width' => ['required', 'numeric'],
                    'text_color' => ['required'],
                ];

            default:
                return [];
        }
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            response()->json([
                'status'  => false,
                'message' => 'validation error',
                'errors'  => $validator->errors(),
            ], 422)
        );
    }
}
