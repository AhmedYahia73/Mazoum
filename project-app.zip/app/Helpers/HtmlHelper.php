<?php






if (! function_exists('Status')) {

    function Status() {
       
        $status = [
            '0' => 'غير مفعل',
            '1' => 'مفعل'
           
        ];

        return $status;
    }
}




