


      <div id="qr-reader" style="width: 500px;display: block;margin: auto;margin-top: 0px;"></div>

	  <div id="qr-reader-results"></div><?php /**PATH /home/mazoom-kw/htdocs/mazoom-kw.com/project-app/resources/views/admin/events/scanner.blade.php ENDPATH**/ ?>