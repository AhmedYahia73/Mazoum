<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\Events as modelRequest;
use App\Http\Controllers\Controller;
use App\Models\Events as Model;
use App\Models\EventUsers;
use App\Models\EventMessages;
use App\Models\CongratulationMessages;
use App\Models\EventUserActions;
use Response;

class EventsController extends Controller
{
    private $view = 'admin.events.';
    private $redirect = 'admin_panel/events';


    public function get_lang()
    {
        $lang = session()->get('admin_lang');

        if($lang == 'en' && $lang != null) {
            return $lang;
        } else {
            return 'ar';
        }
    }


    public function delete_events(Request $request) {

        $request->validate([
            'events' => 'required',
        ]);


      	if($request->events != null && ! empty($request->events)) {

          foreach($request->events as $arr) {

            if(array_key_exists('id', $arr)) {

              $event = Model::withTrashed()->find($arr['id']);

              if($event != null) {
                $event->delete();
              }

            }
          }

        }

        return redirect()->back()->with('success', 'تم الحذف بنجاح');

    }

    public function update_event_package(Request $request,$id) {

        $Item = Model::withTrashed()->findOrFail($id);

        $request->validate([
            //'phone' => 'required',
            // 'invitation_count' => 'required',
            // 'reservation_date' => 'required|date',
            // 'package_price' => 'required',
            // 'payment_type' => 'required',
            // 'is_paid' => 'required',
            'employee_gender' => 'required',
        ]);

        $Item->update($request->only(['employee_gender']));

        return redirect()->back()->with('info',trans('home.update_msg'));
    }


    public function show_pdf($id)
    {

        $Item = Model::withTrashed()->findOrFail($id);

        $filename = 'file';

        $path = $Item->file;

        return Response::make(file_get_contents($path), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="'.$filename.'"'
        ]);

    }

   public function update_location(Request $request) {


     $request->validate([
      	'id' => 'required',
        'lat' => 'required',
        'long' => 'required',
     ]);

      $id = $request->id;
      $lat = $request->lat;
      $long = $request->long;

      $Item = Model::withTrashed()->findOrFail($id);

      $Item->update([
      	'lat' => $lat,
        'long' => $long,
        'country' => $request->country,
        'location' => $request->location,
      ]);

       return redirect()->back()->with('info', trans('home.update_msg'));


   }

    public function index()
    {
        $lang = $this->get_lang();

        if($lang == null) {
            $lang = 'ar';
            app()->setLocale('ar');
            session()->put('admin_lang', 'ar');
        }

        $Item =  Model::where('is_open','yes')->get(['id','title','address','file','user_id','first_name' , 'last_name','date','time']);
        return view($this->view . 'index', compact('Item'));
    }


  	public function closed_events()
    {
        $lang = $this->get_lang();

        if($lang == null) {
            $lang = 'ar';
            app()->setLocale('ar');
            session()->put('admin_lang', 'ar');
        }

        $Item = Model::where('is_open','no')->get(['id','title','address','file','user_id','first_name' , 'last_name','date','time']);
        return view($this->view . 'index', compact('Item'));
    }

    public function deleted_events()
    {
        $lang = $this->get_lang();

        if($lang == null) {
            $lang = 'ar';
            app()->setLocale('ar');
            session()->put('admin_lang', 'ar');
        }

        $Item = Model::onlyTrashed()->get(['id','title','address','file','user_id','first_name' , 'last_name','date','time']);
        return view($this->view . 'index', compact('Item'));
    }


  	public function close_event($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);
        $Item->update(['is_open' => 'no']);
        return redirect('admin_panel/closed-events')->with('success', 'تم اغلاق الحدث بنجاح');
    }


  	public function un_close_event($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);
        $Item->update(['is_open' => 'yes']);
        return redirect('admin_panel/events')->with('success', 'تم فتح الحدث بنجاح');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view($this->view . 'create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(modelRequest $request)
    {

        $Item = Model::withTrashed()->create($this->gteInput($request, null));
        return redirect($this->redirect)->with('success', trans('home.save_msg'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function edit($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        $event_user_ids = EventUserActions::where('event_id',$Item->id)->pluck('event_user_id')->toArray();
        $event_user_ids = array_unique($event_user_ids);
        $event_users = EventUsers::whereIn('id',$event_user_ids)->get();

        if(isset(request()->event_user_id) && request()->event_user_id != null) {

            $event_user = EventUsers::findOrFail(request()->event_user_id);
            $actions = EventUserActions::where('event_id',$id)->where('event_user_id',$event_user->id)->get();

        } else {

            if($event_users != null && $event_users->count() > 0) {

                $event_user = $event_users[0];
                $actions = EventUserActions::where('event_id',$id)->where('event_user_id',$event_user->id)->get();

            } else {

                $event_user = null;
                $actions = null;
            }
        }

        return view($this->view . 'edit', [
            'Item' => $Item,
            'event_users' => $event_users,
            'event_user' => $event_user,
            'actions' => $actions
        ]);
    }


    public function event_visitors($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        return view('admin.event_visitors.index', [ 'Item' => $Item ]);
    }


    public function send_events($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        return view('admin.send_events.index', [ 'Item' => $Item ]);
    }


    public function event_report($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        return view('admin.event_report.index', [ 'Item' => $Item ]);
    }


    public function event_users($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        return view('admin.event_users.index', [ 'Item' => $Item ]);
    }


    public function event_location($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        return view('admin.event_location.index', [ 'Item' => $Item ]);
    }


    public function enter_event($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        return view('admin.enter_event.index', [ 'Item' => $Item ]);
    }


    public function scanner($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        return view('admin.scanner.index', [ 'Item' => $Item ]);
    }


    public function my_package($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        return view('admin.my_package.index', [ 'Item' => $Item ]);
    }


    public function chat_list($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

        $event_user_ids = EventUserActions::where('event_id',$Item->id)->pluck('event_user_id')->toArray();
        $event_user_ids = array_unique($event_user_ids);
        $event_users = EventUsers::whereIn('id',$event_user_ids)->get();

        if(isset(request()->event_user_id) && request()->event_user_id != null) {

            $event_user = EventUsers::findOrFail(request()->event_user_id);
            $actions = EventUserActions::where('event_id',$id)->where('event_user_id',$event_user->id)->get();

        } else {

            if($event_users != null && $event_users->count() > 0) {

                $event_user = $event_users[0];
                $actions = EventUserActions::where('event_id',$id)->where('event_user_id',$event_user->id)->get();

            } else {

                $event_user = null;
                $actions = null;
            }
        }

        return view('admin.chat_list.index', [
            'Item' => $Item,
            'event_users' => $event_users,
            'event_user' => $event_user,
            'actions' => $actions
        ]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(modelRequest $request, $id)
    {
        $Item = Model::withTrashed()->findOrFail($id);
        $Item->update($this->gteInput($request, $Item));

        return redirect()->back()->with('info', trans('home.update_msg'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $Item = Model::withTrashed()->findOrFail($id);

      	$mobiles = EventUsers::where('event_id',$Item->id)->pluck('mobile')->toArray();

      	EventMessages::whereIn('mobile',$mobiles)->delete();
        CongratulationMessages::whereIn('mobile',$mobiles)->delete();

        $Item->delete();

        return redirect($this->redirect)->with('error', trans('home.delete_msg'));
    }


    private function gteInput($request, $modelClass)
    {

        $input = $request->only([
            'title','lat', 'long', 'address', 'showing_qr', 'user_id' ,
            'date','time','enable_resend_again', 'assistant_id','have_reminder',
            'can_replay_messages' , 'gender' , 'sending_type' , 'color'
        ]);

        if(! isset($modelClass)) {
            $input['add_by'] = 'admin';
        } else {
            $input['add_by'] = $modelClass->add_by;
        }

        $path = 'images';

        if($request->file('file') != null) {

            $extension = $request->file('file')->extension();
            $filename = uniqid() . '.' . $extension;
            $request->file('file')->move($path, $filename);

            $input['file'] = $filename;

        }

        if($request->file('image') != null) {

            $extension2 = $request->file('image')->extension();
            $image_name = uniqid() . '.' . $extension2;
            $request->file('image')->move($path, $image_name);

            $input['image'] = $image_name;

        }

        return  $input;
    }


}
