<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Messages;



class MessageController extends Controller
{


    public function contact_messages()
    {
         $Item = Messages::get();
         return view('admin.message.home',compact('Item'));
    }



    public function delete_message($id)
    {

        $message = Messages::findOrFail($id);
        $message->delete();
        return redirect()->back()->with('error','deleted successfully');
    }

     public function seen1($id)
    {

        $message = Messages::findOrFail($id);
        $message->update(['seen' => 1]);

        return redirect()->back()->with('success', 'readed successfully');
    }


}
