<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Subscribers;



class SubscribersController extends Controller
{


    public function subscribers()
    {
         $Item  = Subscribers::get();
         return view('admin.subscribers.index',compact('Item'));
    }


    public function delete_subscriber(Request $request , $id)
    {

        $subscriber = Subscribers::findOrFail($id);
        $subscriber->delete();
        return redirect('admin_panel/subscribers')->with('error','deleted successfully');
    }


    public function seen($id)
    {

        $message = Subscribers::findOrFail($id);
        $message->update(['seen' => 1]);
        return redirect()->back()->with('success','seen successfully');
    }

}
