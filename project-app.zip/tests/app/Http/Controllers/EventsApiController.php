<?php

namespace App\Http\Controllers;

use App\Models\Orders;
use App\Models\Admin;
use App\Models\Setting;
use App\Models\Logs;
use App\Models\EventUsers;
use App\Models\Qr_Code;
use App\Models\EventUserLogs;
use App\Models\Events;
use App\Models\EventMessages;
use App\Models\Parking;
use App\Models\CongratulationMessages;
use App\Models\Notifications;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManagerStatic as Image;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use GuzzleHttp\Client;

class EventsApiController extends Controller
{


    public function accept_event(Request $request)
    {
        info('accept event');
        info($request->all());

        $setting = Setting::first();

        $mobile = ltrim($request->phone,"+");

        $user_event = EventUsers::whereHas('event',function($event) { $event->where('is_open','yes'); })->where('mobile',$mobile)->orderBy('id','desc')->first();

        if($user_event && $user_event->event) {

            $event = Events::find($user_event->event_id);

            $token     = $setting->access_token;
            $sender_id = $setting->sender_id;
            $phone = $mobile;

          	Notifications::create([
            	'add_by'         => 'event_user',
                'user_id'        => $user_event != null ? $user_event->id : 0,
                'send_to_type'   => 'user',
                'send_to_id'     => $user_event->event->user_id,
                'en_title'       => $user_event->event->title,
                'ar_title'       => $user_event->event->title,
                'en_description' => $user_event->name,
                'ar_description' => $user_event->name,
                'type'           => 'accept_event',
                'item_id'        => $user_event->event->id,
                'user_event_id'  => $user_event != null ? $user_event->id : 0,
                'status'         => 'accept_event',
            ]);


          	/* ******************************************************************************************************************************************* */

            $template_name4 = 'car_msg4';

            $url4 = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name4;

            $response4 = SendNewTemplateCodeV1($url4);

            if ($response4 && $response4->getStatusCode() == 200) { // 200 OK

                // $response_data2 = $response2->getBody()->getContents();

                // info($response_data2);

                //dd($response_data,json_decode($response_data,true));
            }

            /* ******************************************************************************************************************************************* */

            $template_name = 'wedding_data_v2_ar';

            $user_event->update([ 'is_accepted' => 'yes' ,'confirmed_at' => now(),'status' => 'attend' ]);

            $url_button = '?q=' . $user_event->event->lat . ',' . $user_event->event->long;

            if($event != null && $event->showing_qr == 'yes') {

                $param_1 = $user_event->name;

                // $url_image = 'https://6gphones.ae/mazoom/public/logo/mazoom.png?2106217949';

                $uu_id = $this->unique_uu_id();
                $bg = 'qr-image-v8.jpg';

                $image_name = $uu_id . '-test-qr.png';

                Qr_Code::create([
                   'event_user_id' => $user_event->id,
                   'event_id' => $user_event->event_id,
                   'qr' => $image_name,
                   'uu_id' => $uu_id,
                   'counter' => 0
                ]);

                $link = asset('scan-qr/' . $uu_id);
                $qr_code_path = 'qr_code/' . $image_name;
                QrCode::size(900)->format('png')->generate($link, $qr_code_path);

                Image::make($bg)->insert($qr_code_path, 'left', 480, 0)->widen(700)->save($qr_code_path, 100);

                $destination = public_path($qr_code_path);

                $new_img = Image::make($destination);

                $new_img->text($user_event->users_count, 150, 615, function ($font) {
                    $font->file(public_path('font/OpenSans-Italic.ttf'));
                    $font->size(40);
                    $font->color('#eeb534');
                });

              	$new_img->text($user_event->mobile, 190, 680, function ($font) {
                    $font->file(public_path('font/OpenSans-Italic.ttf'));
                    $font->size(30);
                    $font->color('#000');
                    //$font->align('right'); // Adjust alignment if necessary
                });

                $new_img->save($destination);

                $url_image = asset($qr_code_path);

                $url = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name.'&param_1='.$user_event->users_count.'&image='.$url_image.'&url_button='.$url_button;

                $response = SendNewTemplateCodeV1($url);

                if ($response && $response->getStatusCode() == 200) { // 200 OK

                    // $response_data = $response->getBody()->getContents();

                    // info($response_data);

                    //dd($response_data,json_decode($response_data,true));

                    $user_event->update([ 'qr_sent' => 'yes'  ]);

                    EventUserLogs::create([
                      'log' => "تم ارسال ال QR Code",
                      'event_id' => $user_event->event_id,
                      'event_user_id' => $user_event->id,
                      'message_id' => $user_event->message_id,
                      'status' => 'attend',
                      'error_title' => null,
                      'error_details' => null,
                    ]);
                }

            }

          	sleep(5);

            /* ******************************************************************************************************************************************* */

            $template_name3 = 'mazoom_qr2';

            $url3 = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name3;

            $response3 = SendNewTemplateCodeV1($url3);

          	//info($response3);
          	//info($response3->getBody()->getContents());

            if ($response3 && $response3->getStatusCode() == 200) { // 200 OK

                // $response_data2 = $response2->getBody()->getContents();

                // info($response_data2);

                //dd($response_data,json_decode($response_data,true));
            }

            /* ******************************************************************************************************************************************* */

            sleep(4);

            $template_name2 = 'send_congratulation_ar_new';

            $url2 = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name2;

            $response2 = SendNewTemplateCodeV1($url2);

            if ($response2 && $response2->getStatusCode() == 200) { // 200 OK

                // $response_data2 = $response2->getBody()->getContents();

                // info($response_data2);

                //dd($response_data,json_decode($response_data,true));
            }


        }

    }



  	public function resend_qr_code(Request $request)
    {
        // info('resend_qr_code');
        // info($request->all());

        $setting = Setting::first();

        $mobile = ltrim($request->phone,"+");

        $user_event = EventUsers::whereHas('event',function($event) { $event->where('is_open','yes'); })->where('mobile',$mobile)->orderBy('id','desc')->first();

        if($user_event) {

            $event = Events::find($user_event->event_id);

            $token     = $setting->access_token;
            $sender_id = $setting->sender_id;
            $phone = $mobile;
            $template_name = 'wedding_data_v2_ar';

            $user_event->update([ 'is_accepted' => 'yes'  ]);

            $url_button = '?q=' . $user_event->event->lat . ',' . $user_event->event->long;

              if($event != null && $event->showing_qr == 'yes') {

                $param_1 = $user_event->name;

                // $url_image = 'https://6gphones.ae/mazoom/public/logo/mazoom.png?2106217949';

              	$check_Qr_Code = Qr_Code::where('event_id',$user_event->event_id)->where('event_user_id',$user_event->id)->first();

                if($check_Qr_Code) {

                  $uu_id = $check_Qr_Code->uu_id;

                  $image_name = $uu_id . '-test-qr.png';

                  $link = asset('scan-qr/' . $uu_id);
                  $qr_code_path = 'qr_code/' . $image_name;

                } else {

                   $uu_id = $this->unique_uu_id();

                    $image_name = $uu_id . '-test-qr.png';

                  	$check_Qr_Code = Qr_Code::create([
                       'event_user_id' => $user_event->id,
                       'event_id' => $user_event->event_id,
                       'qr' => $image_name,
                       'uu_id' => $uu_id,
                       'counter' => 0
                    ]);

                  	$bg = 'qr-image-v8.jpg';

                    $link = asset('scan-qr/' . $uu_id);
                    $qr_code_path = 'qr_code/' . $image_name;
                    QrCode::size(900)->format('png')->generate($link, $qr_code_path);

                    Image::make($bg)->insert($qr_code_path,  'left', 480, 0)->widen(700)->save($qr_code_path, 100);

                    $destination = public_path($qr_code_path);

                    $new_img = Image::make($destination);

                    $new_img->text($user_event->users_count, 150, 615, function ($font) {
                        $font->file(public_path('font/OpenSans-Italic.ttf'));
                        $font->size(40);
                        $font->color('#eeb534');
                    });

                    $new_img->save($destination);

                }


                $url_image = asset($qr_code_path);

                $url = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name.'&param_1='.$user_event->users_count.'&image='.$url_image.'&url_button='.$url_button;

                $response = SendNewTemplateCodeV1($url);

                if ($response && $response->getStatusCode() == 200) { // 200 OK

                    // $response_data = $response->getBody()->getContents();

                    // info($response_data);

                    //dd($response_data,json_decode($response_data,true));

                    $user_event->update([ 'qr_sent' => 'yes'  ]);

                    EventUserLogs::create([
                      'log' => "تم ارسال ال QR Code",
                      'event_id' => $user_event->event_id,
                      'event_user_id' => $user_event->id,
                      'message_id' => $user_event->message_id,
                      'status' => 'attend',
                      'error_title' => null,
                      'error_details' => null,
                    ]);
                }

            }

        }

    }



    public function refuse_event(Request $request)
    {
        // info('refuse event');
        // info($request->all());

        $setting = Setting::first();

        $mobile = ltrim($request->phone,"+");

        $user_event = EventUsers::whereHas('event',function($event) { $event->where('is_open','yes'); })->where('mobile',$mobile)->orderBy('id','desc')->first();

        if($user_event && $user_event->event) {

          	Notifications::create([
            	'add_by'         => 'event_user',
                'user_id'        => $user_event != null ? $user_event->id : 0,
                'send_to_type'   => 'user',
                'send_to_id'     => $user_event->event->user_id,
                'en_title'       => $user_event->event->title,
                'ar_title'       => $user_event->event->title,
                'en_description' => $user_event->name,
                'ar_description' => $user_event->name,
                'type'           => 'refuse_event',
                'item_id'        => $user_event->event->id,
                'user_event_id'  => $user_event != null ? $user_event->id : 0,
                'status'         => 'refuse_event',
            ]);

            Qr_Code::where('event_user_id', $user_event->id)->delete();

            $user_event->update([ 'scan' => null , 'scan_at' => null, 'is_refused' => 'yes','is_accepted' => 'no' ,'status' => 'not-attend'  ]);

            $event = Events::find($user_event->event_id);

            $token     = $setting->access_token;
            $sender_id = $setting->sender_id;
            $phone = $mobile;
            $template_name = 'wedding_data_v3_ar';

            $url = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name;

            $response = SendNewTemplateCodeV1($url);

            if ($response && $response->getStatusCode() == 200) { // 200 OK

                // $response_data = $response->getBody()->getContents();

                // info($response_data);

                //dd($response_data,json_decode($response_data,true));
            }

        }
    }



    public function save_congratulation_msg(Request $request)
    {
        // info('congratulation msg');

        // info($request->all());

        $setting = Setting::first();

        $mobile = ltrim($request->phone,"+");

        $user_event = EventUsers::whereHas('event',function($event) { $event->where('is_open','yes'); })->where('mobile',$mobile)->orderBy('id','desc')->first();

        CongratulationMessages::create([
          'event_id' => $user_event != null ? $user_event->event_id : 0,
          'event_user_id' => $user_event != null ? $user_event->id : 0,
          'name' => $user_event != null ? $user_event->name : '',
          'mobile' => $mobile,
          'message' => $request->msg
        ]);

      	if($user_event != null && $user_event->event) {
      		Notifications::create([
              'add_by'         => 'event_user',
              'user_id'        => $user_event != null ? $user_event->id : 0,
              'send_to_type'   => 'user',
              'send_to_id'     => $user_event->event->user_id,
              'en_title'       => $user_event->event->title,
              'ar_title'       => $user_event->event->title,
              'en_description' => $request->msg,
              'ar_description' => $request->msg,
              'type'           => 'event-msg',
              'item_id'        => $user_event->event->id,
              'user_event_id'  => $user_event != null ? $user_event->id : 0,
              'status'         => 'new_msg',
            ]);
        }


    }



    public function save_apology_msg(Request $request)
    {
        // info('apology msg');

        // info($request->all());

        $setting = Setting::first();

        $mobile = ltrim($request->phone,"+");

        $user_event = EventUsers::whereHas('event',function($event) { $event->where('is_open','yes'); })->where('mobile',$mobile)->orderBy('id','desc')->first();

        EventMessages::create([
            'event_id' => $user_event != null ? $user_event->event_id : 0,
            'event_user_id' => $user_event != null ? $user_event->id : 0,
            'name' => $user_event != null ? $user_event->name : '',
            'mobile' => $mobile,
            'message' => $request->msg
        ]);

      	if($user_event != null && $user_event->event) {
      		Notifications::create([
              'add_by'         => 'event_user',
              'user_id'        => $user_event != null ? $user_event->id : 0,
              'send_to_type'   => 'user',
              'send_to_id'     => $user_event->event->user_id,
              'en_title'       => $user_event->event->title,
              'ar_title'       => $user_event->event->title,
              'en_description' => $request->msg,
              'ar_description' => $request->msg,
              'type'           => 'event-msg',
              'item_id'        => $user_event->event->id,
              'user_event_id'  => $user_event != null ? $user_event->id : 0,
              'status'         => 'new_msg',
            ]);
        }

    }



    public function location_event(Request $request)
    {
        // info('location event');
        // info($request->all());

        $setting = Setting::first();

        $mobile = ltrim($request->phone,"+");

        $user_event = EventUsers::whereHas('event',function($event) { $event->where('is_open','yes'); })->where('mobile',$mobile)->orderBy('id','desc')->first();

        if($user_event) {

            $event = Events::find($user_event->event_id);

            if($event) {

                $user_event->update([ 'get_location' => 'yes' ]);

                $token     = $setting->access_token;
                $sender_id = $setting->sender_id;
                $phone = $mobile;
                $template_name = 'wedding_data_v7_ar';
                $param_1 = $user_event->name;

                $url_button = '?q=' . $event->lat . ',' . $event->long;

                $url = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name.'&param_1='.$param_1.'&url_button='.$url_button;

                $response = SendNewTemplateCodeV1($url);

                if ($response && $response->getStatusCode() == 200) { // 200 OK

                    // $response_data = $response->getBody()->getContents();

                    // info($response_data);

                    //dd($response_data,json_decode($response_data,true));
                }

            }

        }
    }


    public function event_date(Request $request)
    {
        // info('event date');
        // info($request->all());

        $setting = Setting::first();

        $mobile = ltrim($request->phone,"+");

        $user_event = EventUsers::whereHas('event',function($event) { $event->where('is_open','yes'); })->where('mobile',$mobile)->orderBy('id','desc')->first();

        if($user_event) {

            $event = Events::find($user_event->event_id);

            if($event) {

                $token     = $setting->access_token;
                $sender_id = $setting->sender_id;
                $phone = $mobile;
                $template_name = 'wedding_data_v9_ar';

                $param_1 = $event->date;

                $url = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name.'&param_1='.$param_1;

                $response = SendNewTemplateCodeV1($url);

                if ($response && $response->getStatusCode() == 200) { // 200 OK

                    // $response_data = $response->getBody()->getContents();

                    // info($response_data);

                    //dd($response_data,json_decode($response_data,true));
                }


            }
        }
    }





    private function unique_uu_id()
    {
        $uu_id = random_int(10000, 99999);

        while (Qr_Code::where('uu_id', $uu_id)->exists()) {
            $uu_id = random_int(10000, 99999);
        }

        return $uu_id;
    }



     // public function confirm_send_congratulations(Request $request)
    // {
    //     // info('confirm send congratulations');
    //     // info($request->all());

    //     $setting = Setting::first();

    //     $mobile = ltrim($request->phone,"+");

    //     $user_event = EventUsers::where('mobile',$mobile)->orderBy('id','desc')->first();

    //     if($user_event) {

    //         $token     = $setting->access_token;
    //         $sender_id = $setting->sender_id;
    //         $phone = $mobile;
    //         $template_name = 'wedding_data_v12_ar';

    //         $url = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name;

    //         $response = SendNewTemplateCodeV1($url);

    //         if ($response && $response->getStatusCode() == 200) { // 200 OK

    //             $response_data = $response->getBody()->getContents();

    //             // info($response_data);

    //             //dd($response_data,json_decode($response_data,true));
    //         }

    //     }
    // }


    // public function confirm_send_apology(Request $request)
    // {
    //     // info('confirm send congratulations');
    //     // info($request->all());

    //     $mobile = ltrim($request->phone,"+");

    //     $user_event = EventUsers::where('mobile',$mobile)->orderBy('id','desc')->first();

    //     if(1 == 1) {

    //         $token = 'EAAMsejfnW3YBO8Dyx2A33sCNgtAcJ4TNlOBrQ3LWP32viFq2ZB2UCR7w1NF5iCOxCsn5DNZAoK9qwCISeDDA7C91bjdfVzLau1pze5huMjn0d9FFW8ri1k33o8kQelh32ayQZBvDwJtcJNJiebk7BAGT34kUUe3E0YutgnHPbafP3IZCx14OQqNp4TAfCR6o';
    //         $sender_id = '344115548775193';
    //         $phone = '96597378181';
    //         $template_name = 'wedding_data_v12_ar';

    //         $url = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name;

    //         $response = SendNewTemplateCodeV1($url);

    //         if ($response && $response->getStatusCode() == 200) { // 200 OK

    //             $response_data = $response->getBody()->getContents();

    //             // info($response_data);

    //             //dd($response_data,json_decode($response_data,true));
    //         }

    //     }
    // }





}
