<?php


namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class Desgins extends FormRequest
{

    public function get_lang()
    {
        $lang = session()->get('admin_lang');

        if($lang == 'en' && $lang != null) {
            return $lang;
        } else {
            return 'ar';
        }
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function rules()
    {

        switch($this->method())
        {
            case 'GET':
            case 'DELETE':
            {
                return [];
            }
            case 'POST':
            {
                return [
                    'en_name' => 'required',
                    'ar_name' => 'required',
                    'file' => 'required|mimes:pdf,jpg,png,jpeg',
                ];
            }
            case 'PUT':
            case 'PATCH':
            {
                return [
                    'en_name' => 'required',
                    'ar_name' => 'required',
                    'file' => 'nullable|mimes:pdf,jpg,png,jpeg',
                ];

            }
            default:break;
        }
    }

    public function messages()
    {

        $lang = $this->get_lang();

        if($lang == null) {
            $lang = 'ar';app()->setLocale('ar');session()->put('admin_lang','ar');
        }

        if($lang == 'ar') {

            // use trans instead on Lang
            return [
                'en_name.required' => ' الأسم باللغة الانجليزية مطلوب ',
                'ar_name.required' => 'الأسم باللغة بالعربية مطلوب',

                'file.required' =>  'المرفق مطلوب',
                'file.mimes' =>  'يجب أن يكون امتداد الملف jpg و png و jpeg و pdf',
            ];

        } else {

            return [
                'en_name.required' => ' en name required ',
                'ar_name.required' => ' ar name required ',

                'file.required' =>  'file is required',
                'file.mimes' =>  'file must have only extensions pdf,jpg,png,jpeg',
            ];
        }

    }






}
