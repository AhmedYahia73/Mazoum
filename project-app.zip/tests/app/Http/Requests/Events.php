<?php


namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class Events extends FormRequest
{

    public function get_lang()
    {
        $lang = session()->get('admin_lang');

        if($lang == 'en' && $lang != null) {
            return $lang;
        } else {
            return 'ar';
        }
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function rules()
    {

        switch($this->method())
        {
            case 'GET':
            case 'DELETE':
            {
                return [];
            }
            case 'POST':
            {
                return [
                    'title' => 'required',
                    'address' => 'required',
                    'file' => 'required|mimes:pdf,jpg,png,jpeg',
                    'showing_qr' => 'required',
                    'user_id' => 'required|exists:users,id',
                    'date' => 'required|date|date_format:Y-m-d',
                    'time' => 'required',
                    'enable_resend_again' => 'required|in:yes,no',
                    'sending_type' => 'required|in:old_send,new_send,not_available',
                ];
            }
            case 'PUT':
            case 'PATCH':
            {
                return [
                    'title' => 'required',
                    'address' => 'required',
                    'file' => 'nullable|mimes:pdf,jpg,png,jpeg',
                    'showing_qr' => 'required',
                    'user_id' => 'nullable|exists:users,id',
                    'date' => 'required|date|date_format:Y-m-d',
                    'time' => 'required',
                    'enable_resend_again' => 'required|in:yes,no',
                    'sending_type' => 'required|in:old_send,new_send,not_available',
                ];

            }
            default:break;
        }
    }

    public function messages()
    {

        $lang = $this->get_lang();

        if($lang == null) {
            $lang = 'ar';app()->setLocale('ar');session()->put('admin_lang','ar');
        }

        if($lang == 'ar') {

            // use trans instead on Lang
            return [
                'title.required' => ' عنوان الحدث مطلوب ',
                'address.required' => 'موقع الحدث مطلوب',
                'showing_qr' => 'اظهار كود ال qr  مطلوب',
                'user_id' => 'رقم المستخدم مطلوب',
                'user_id.exists' => 'عفوا هذا المستخد غير موجود مسبقا',

                'file.required' =>  'المرفق مطلوب',
                'file.mimes' =>  'يجب أن يكون امتداد الملف jpg و png و jpeg و pdf',
            ];

        } else {

            return [
                'title.required' => ' event title is required ',
                'address.required' => ' event location is required ',
                'showing_qr.required' => ' showing qr is required ',
                'user_id' => 'user id is required',

                'file.required' =>  'file is required',
                'file.mimes' =>  'file must have only extensions pdf,jpg,png,jpeg',
            ];
        }

    }






}
