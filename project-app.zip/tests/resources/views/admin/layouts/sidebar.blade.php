


    <li class="menu-item {{ count(Request::segments()) == 1 ? 'active' : '' }}">
        <a href="{{asset('admin_panel')}}" class="menu-link">
            <i class="menu-icon tf-icons bx bx-calendar"></i>
            <div data-i18n="{{ trans('home.dashboard') }}">
                {{ trans('home.dashboard') }}
            </div>
        </a>
    </li>


    <li class="menu-item {{ request()->is('admin_panel/admin*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/manager')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="{{ trans('home.managers') }}">
            {{ trans('home.managers') }}
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/currency*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/currency')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="العملات">
            العملات
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/mobile_codes*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/mobile_codes')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="أكواد الموبيل">
            أكواد الموبيل
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/users*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/users')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="{{ trans('home.users') }}">
            {{ trans('home.users') }}
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/assistant*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/assistant')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="الموظفين">
            الموظفين
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/setting*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/setting')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="{{ trans('home.setting') }}">
            {{ trans('home.setting') }}
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/uses*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/uses')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="كيفية الأستخدام">
            كيفية الأستخدام
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/packages*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/packages')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="الباقات">
            الباقات
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/reservation*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/reservation')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="حجز باقات معزوم">
            حجز باقات معزوم
        </div>
        </a>
    </li>


    <li class="menu-item {{ request()->is('admin_panel/pricing*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/pricing')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="باقات الموقع">
            باقات الموقع
        </div>
        </a>
    </li>


    <li class="menu-item {{ request()->is('admin_panel/desgins*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/desgins')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="تصميمات التطبيق">
            تصميمات التطبيق
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/web_desgins*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/web_desgins')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="تصميمات الموقع">
            تصميمات الموقع
        </div>
        </a>
    </li>





    <li class="menu-item {{ request()->is('admin_panel/events*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/events')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="الأحداث">
            الأحداث
        </div>
        </a>
    </li>


    <li class="menu-item {{ request()->is('admin_panel/custom_events*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/custom_events')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="دعوات خاصة">
            دعوات خاصة
        </div>
        </a>
    </li>



    <li class="menu-item {{ request()->is('admin_panel/messages*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/messages')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="الرسائل">
            الرسائل
        </div>
        </a>
    </li>

    <li class="menu-item {{ request()->is('admin_panel/subscribers*') ? 'active' : '' }}">
        <a href="{{asset('admin_panel/subscribers')}}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-calendar"></i>
        <div data-i18n="الأشتركات">
            الأشتركات
        </div>
        </a>
    </li>




