@extends('assistant.layouts.master')
{{-- title --}}

@section('title','تعديل موظف')

@section('header')

  <style>
    .card-body .col-lg-12 , .card-body .col-lg-6 { margin-bottom: 20px }

    .card-body { padding-bottom: 0 !important}

  </style>


@endsection

@section('content')



<!-- Basic Inputs start -->
<section id="basic-input">

  @include('flash-message')


  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">
            تعديل موظف
          </h4>
        </div>


        <!--begin::Form-->
        {!! Form::open(['url' => "assistant_panel/profile", 'role'=>'form','id'=>'edit','method'=>'post', 'files' => true]) !!}

           <div class="card-body">

                <div class="row">

                    <div class="col-lg-6 {{ $errors->has('name') ? ' has-error' : '' }}">
                        <label>  {{ trans('home.name') }} <span class="text-danger">*</span>  </label>
                        <input type="text" name="name" class="form-control m-input" required="required" value="{{ $Item->name }}" placeholder=" {{ trans('home.name') }}  ">
                        @if ($errors->has('name'))
                            <span class="help-block" style="color:red">
                                <strong>{{ $errors->first('name') }} </strong>
                            </span>
                        @endif
                    </div>

                    <div class="col-lg-6 {{ $errors->has('email') ? ' has-error' : '' }}">
                        <label>{{ trans('home.email') }}  <span class="text-danger">*</span>   </label>
                        <input type="email" name="email" class="form-control m-input" required="required" value="{{ $Item->email }}" placeholder="  {{ trans('home.email') }}  ">
                        @if ($errors->has('email'))
                            <span class="help-block" style="color:red">
                                <strong>{{ $errors->first('email') }} </strong>
                            </span>
                        @endif
                    </div>

                    <div class="col-lg-6 {{ $errors->has('mobile') ? ' has-error' : '' }}">
                        <label>  {{ trans('home.mobile') }}   <span class="text-danger">*</span>  </label>
                        <input type="text" name="mobile" class="form-control m-input" required="required" value="{{ $Item->mobile }}" placeholder=" {{ trans('home.mobile') }}     ">
                        @if ($errors->has('mobile'))
                                <span class="help-block" style="color:red">
                                    <strong>{{ $errors->first('mobile') }} </strong>
                                </span>
                        @endif
                    </div>

                    <div class="col-lg-6 {{ $errors->has('password') ? ' has-error' : '' }}">
                            <label>  {{ trans('home.password') }}   </label>
                            <input type="password" name="password" class="form-control m-input" value="" placeholder="  {{ trans('home.password') }}  ">
                            @if ($errors->has('password'))
                                <span class="help-block" style="color:red">
                                    <strong>{{ $errors->first('password') }} </strong>
                                </span>
                            @endif
                    </div>

                </div>

           </div>

           <div class="card-footer" style="padding-left: 25px !important;margin-top: 0px !important;">
              <button type="submit" form="edit" class="btn btn-primary mr-2">
                {{ trans('home.update') }}
              </button>
           </div>

       {!! Form::close() !!}
        <!--end::Form-->



      </div>
    </div>
  </div>
</section>
<!-- Basic Inputs end -->


@endsection


@section('footer')

    <script>
        function isNumberKey(evt){
            var charCode = (evt.which) ? evt.which : evt.keyCode
            //return !(charCode > 31 && (charCode < 48 || charCode > 57));

            if(! (charCode >= 48 && charCode <= 57) ) {
                return false;
            }
        }
    </script>

@endsection

