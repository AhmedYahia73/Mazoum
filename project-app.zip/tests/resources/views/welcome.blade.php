<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> {{ $counter == 0 ? 'مسح صحيح' : 'مسح غير صحيح' }}  </title>
        <link href="{{ asset('auth/bootstrap.min.css') }}" rel="stylesheet">
      
      	<link rel="stylesheet" href="{{ asset('arabic_font') }}/droidarabickufi.css"/>


        <style>
          
          body {
          	background: #EEE;
          }
          
          body, html, h1, h2, h3, h4, h5, h6, p, li, .btn ,select , .btn-primary,
          .theme-green .back-bar .pointer-label , .custom_font
          {
            font-family: 'DroidArabicKufiRegular', sans-serif !important;
          }

          ::-webkit-input-placeholder {
            /* Chrome/Opera/Safari */
            font-family: 'DroidArabicKufiRegular', sans-serif !important;
          }
          ::-moz-placeholder {
            /* Firefox 19+ */
            font-family: 'DroidArabicKufiRegular', sans-serif !important;
          }
          :-ms-input-placeholder {
            /* IE 10+ */
            font-family: 'DroidArabicKufiRegular', sans-serif !important;
          }
          :-moz-placeholder {
            /* Firefox 18- */
            font-family: 'DroidArabicKufiRegular', sans-serif !important;
          }

         </style>

  
    </head>

    <body>
        <div class="vh-100 d-flex justify-content-center align-items-center">
          
          	@if($counter == 0)
          
          	<div class="card" style="min-width: 500px;">
              <div class="card-header" style="text-align: center;background: #16AA68;color: #FFF;">
                
                	<img src="{{ asset('check.png') }}" style="max-width: 140px;margin-top: 30px;margin-bottom: 20px;">
                
                    <h2 style="margin-bottom: 20px;" class="custom_font"> مسح صحيح </h2>
              </div>
              <div class="card-body">
              	<div class="text-center">
                  
                    <p class="custom_font" style="font-size: 25px"> نتطلع الي رؤيتك في الحدث </p>
                  	
                  	<p class="custom_font">  
                      <span> عدد المدعوين  </span>
                      <span> ( {{ $user_event->users_count }} ) </span>
                      
                      <span> - </span>
                      
                      <span> اللذين اكدوا الحضور </span>
                      <span> ( {{ $user_event->scan_count }} ) </span>
                    </p>
                  
                  
                  	<p class="custom_font">  
                      <span> الأسم </span>
                      <span> ( {{ $user_event->name }} ) </span>
                    </p>
                  
                  	@if($user_event->mobile)
                  	<p class="custom_font">  
                      <span> رقم الموبيل </span>
                      <span> ( {{ $user_event->mobile }} ) </span>
                    </p>
                  	@ENDIF
                  
                </div>
              </div>
            </div>
          
          	@else
          
          	<div class="card" style="min-width: 500px;">
              <div class="card-header" style="text-align: center;background: #F6AE1A;color: #FFF;">
                
                	<img src="{{ asset('error.png') }}" style="max-width: 140px;margin-top: 30px;margin-bottom: 20px;">
                
                    <h2 style="margin-bottom: 20px;" class="custom_font"> مسح غير صحيح </h2>
              </div>
              <div class="card-body" style="height: 125px;line-height: 100px;">
              	<div class="text-center">
                  
                  
                    <!--<p style="font-size: 20px;"> يبدو أنك قمت بمسح هذه الدعوه من قبل شكرا </p>-->
                  
                  	<p style="font-size: 20px;">
                    	عفوا لقد تخطيت العدد المسموح به لمسح ال QR  
                  	</p>
                  	
                </div>
              </div>
            </div>
          

          	@endif
     
      </div>
    </body>

</html>
