<?php

use App\Models\Orders;
use App\Models\Squares;
use App\Models\Admin;
use  App\Models\Setting;
use App\Models\Qr_Code;
use App\Models\EventUsers;
use App\Models\CustomEventUsers;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Intervention\Image\ImageManagerStatic as Image;
use Carbon\Carbon;




Route::get('test-qr', function () {
    
    $uu_id = 123;

    $bg = 'custom_event_qr_code/custom_qr2.jpg';
    $image_name = $uu_id . '-custom-event-qr.png';
    $link = asset('scan-custom-event-qr/' . $uu_id);
    $qr_code_path = 'custom_event_qr_code/' . $image_name;

    // إنشاء QR كـ صورة مؤقتة
    $qr_temp_path = public_path('custom_event_qr_code/temp_' . $image_name);
    QrCode::size(330)->format('png')->generate($link, $qr_temp_path);

    // افتح الخلفية
    $background = Image::make(public_path($bg));

    // افتح QR
    $qr = Image::make($qr_temp_path);

    // احسب الإحداثيات لتوسيط QR في الأسفل
    $x = intval(($background->width() - $qr->width()) / 2); // مركز أفقي
    $y = $background->height() - $qr->height() - 100; // من الأسفل

    // أدرج QR
    $background->insert($qr, 'top-left', $x, $y + 60);

    // احسب مركز الصورة للنص
    $center_x = intval($background->width() / 2);
    $text_y = $y + $qr->height() + 70; // أسفل QR بـ 20px

    // أضف النص في وسط الصورة أفقيًا وأسفل QR
    $background->text('sayed oraby', $center_x, $text_y, function ($font) {
        $font->file(public_path('font/OpenSans-Italic.ttf'));
        $font->size(28);
        $font->color('#000');
        $font->align('center');
        $font->valign('top');
    });

    // حفظ النتيجة
    $background->save(public_path($qr_code_path), 100);

    // حذف QR المؤقت
    @unlink($qr_temp_path);

    dd('ok');
});



Route::get('test-qr2', function () {

    // $link = 'https://techvblogs.com/blog/generate-qr-code-laravel-8';
    // QrCode::size(100)->format('png')->generate($link, 'test-qr.png');
    // dd('ok');

    $setting = Setting::first();

    $link = 'https://www.acacia-uae.ae';
  	
  
    $bg = 'qr-image-v8.jpg';

    $image_name =  '123-test-qr.png';
  
    $qr_code_path = 'qr_code/'.$image_name;
    QrCode::size(900)->format('png')->generate($link, $qr_code_path);

    Image::make($bg)->insert($qr_code_path, 'left', 480, 0)->widen(700)->save($qr_code_path, 100);

    $destination = public_path($qr_code_path);

    $new_img = Image::make($destination);

    $new_img->text(2, 150, 615, function ($font) {
      $font->file(public_path('font/OpenSans-Italic.ttf'));
      $font->size(40);
      $font->color('#eeb534');
    });

    $new_img->save($destination);

	
    $image_url = asset($qr_code_path);

  	$sender_id = $setting->sender_id;
    $phone = 201008478014;
    $template_name = 'wedding_data_v2_ar';
    $language = 'ar';
    $url_image = $image_url;
    $param_1 = 'sayed';
    $phone_numer_id = $setting->phone_numer_id;
    $token = $setting->access_token;
  
    //$response = SendTemplateV2($to, $template_name, $language, $image_url, $user_name, $phone_numer_id, $token);

  
    $url = 'https://api.karzoun.app/CloudApi.php?token='.$token.'&sender_id='.$sender_id.'&phone='.$phone.'&template='.$template_name.'&param_1='.$param_1.'&image='.$url_image;
            
    $response = SendNewTemplateCodeV1($url);
  
    dd('ok');

});





Route::get('login', function () {

    if(auth()->guard('assistant')->check()) {
        return redirect('assistant_panel');
    } else {
        return view('login');
    }

});


Route::get('logout', function () {

    if(auth()->guard('assistant')->check()) {
        auth()->guard('assistant')->logout();
        return redirect('assistant_panel');
    } else {
        return redirect('assistant_panel/login');
    }

});


Route::post('login', function (Request $request) {


    $request->validate([
        'email' => 'required|email',
        'password' => 'required',
    ]);

    $remember = true;

    if (auth()->guard('assistant')->attempt([ 'email' => request('email') , 'password' => request('password')], $remember)) {
        return redirect('assistant_panel')->with('success', 'تم تسجيل الدخول بنجاح');

    } else {
        return redirect()->back()->with('error', 'برجاء التحقق من البريد الألكتروني وكلمة المرور مره أخري');
    }

});



Route::get('scan-qr/{uu_id}', function ($uu_id) {
  
  
    if(auth()->guard('assistant')->check() || auth()->guard('admin')->check()) {
      
      	$now = Carbon::now();
      
        $Item = Qr_Code::where('uu_id', $uu_id)->firstOrFail();
            
        $user_event = EventUsers::where('id', $Item->event_user_id)->firstOrFail();
      
      	$counter = $Item->counter;
      
        if($counter == 0) {
            $user_event->update(['scan' => 'yes','scan_at' => $now]);
            $Item->update(['counter' => $Item->counter + 1]);
            $msg = 'welcome '.$user_event->name;
        } else {
            $msg = 'sorry this qr code is scaned before';
        }
      
        return view('welcome', compact('msg','counter','user_event'));

    } else {
        return view('not_auth_qr');
    }

});



Route::get('scan-qr/{uu_id}', function ($uu_id) {
  
  
    if(auth()->guard('assistant')->check() || auth()->guard('admin')->check()) {
      
      	$now = Carbon::now();
      
        $Item = Qr_Code::where('uu_id', $uu_id)->firstOrFail();
            
        $user_event = EventUsers::where('id', $Item->event_user_id)->firstOrFail();
      
      	$counter = $Item->counter;
      
        if($user_event->scan_count < $user_event->users_count) {
            $user_event->update(['scan' => 'yes','scan_at' => $now,'scan_count' => $user_event->scan_count + 1]);
            $Item->update(['counter' => $Item->counter + 1]);
            $msg = 'welcome '.$user_event->name;
        	$counter = 0;
        } else {
          	$counter = 1;
            $msg = 'sorry this qr code is scaned before';
        }
      
        return view('welcome', compact('msg','counter','user_event'));

    } else {
        return view('not_auth_qr');
    }

});



Route::get('scan-custom-event-qr/{uu_id}', function ($uu_id) {
  
  
  
    if(auth()->guard('assistant')->check() || auth()->guard('admin')->check()) {
      
      	$now = Carbon::now();
      
        $Item = CustomEventUsers::where('uu_id', $uu_id)->firstOrFail();
                        
      	$user_event = $Item;
      
        if($Item->scan_count < $Item->users_count) {
            $user_event->update(['scan' => 'yes','scan_at' => $now,'scan_count' => $Item->scan_count + 1]);
            $Item->update(['counter' => $Item->counter + 1]);
            $msg = 'welcome '.$user_event->name;
          	$counter = 0;
        } else {
          	$counter = 1;
            $msg = 'عفوا لقد تخطيت العدد المسموح به لمسح ال QR';
        }
      
        return view('welcome', compact('msg','counter','user_event'));

    } else {
        return view('not_auth_qr');
    }

});




Route::get('test', 'HomeController@test');



Route::get('send-messge', function () {

    // Request body
    $arr = [
      'messaging_product' => 'whatsapp',
      'to' => '201008478014',
      'type' => 'template',
      'template' => [
            'name' => 'hello_world',
            'language' => [
                'code' => 'en_US'
            ]
       ],
    ];


    $fullUrl = 'https://graph.facebook.com/v15.0/108343618828034/messages';

    $client = new Client();

    $response = $client->post($fullUrl, [
        'headers' => [
            'Authorization' => 'Bearer EAAWeVL00ZC1UBAOlKcG2qxS71PMut33UNJ2ZBtt9XdblOUcOoZAodeOKb9VYAuaX9TC5DHt5FsMZCZAsGE65J5UnR9Kn1qMO75nngKoj3QxW2l3FIrVPo3fZCg6LKZCsEea5DkXzBPvfJtnbtt1MVv16Ab7bEb5pvVdJKd8BQtTJQJ3Rnq5VudZBX5GdmQKi0xRNRBZBG5ZCNmjd2XzVk5LE7zfMk5yJgjIwsZD',
        ],
        'json' => $arr,
    ]);


    dd($response->getStatusCode(), $response->getBody());

});


Route::get('send-messge-v2', function () {

    // Request body
    try {

        $arr = [
          'messaging_product' => 'whatsapp',
          'recipient_type' => 'individual',
          'to' => '201008478014',
          'type' => 'template',
          'template' => [
                'name' => 'wedding_v2',
                'language' => [
                    'code' => 'en'
                ],
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            [
                                'type' => 'image',
                                'image' => [
                                    'link' => 'https://media.istockphoto.com/id/1190043570/photo/happy-wedding-photography-of-bride-and-groom-at-wedding-ceremony-wedding-tradition-sprinkled.jpg?s=612x612&w=0&k=20&c=_aCIW5-iOIiaDdqin_50kvBcbFbIxSULHHamPUILE0c=',
                                ],
                            ]
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            [
                                'type' => 'text',
                                'text' => 'Mr Saeed'
                            ],
                            [
                                'type' => 'text',
                                'text' => 'Sayed'
                            ],
                            [
                                'type' => 'text',
                                'text' => 'Alaa'
                            ],
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'quick_reply',
                        'index' => '0',
                        'parameters' => [
                            [
                                'type' => 'PAYLOAD',
                                'payload' => 'attend'
                            ]
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'quick_reply',
                        'index' => '1',
                        'parameters' => [
                            [
                                'type' => 'payload',
                                'payload' => 'not-attend'
                            ]
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'quick_reply',
                        'index' => '2',
                        'parameters' => [
                            [
                                'type' => 'payload',
                                'payload' => 'location'
                            ]
                        ],
                    ],
                ]
           ],
        ];


        $fullUrl = 'https://graph.facebook.com/v16.0/108343618828034/messages';

        $client = new Client();

        $response = $client->post($fullUrl, [
            'headers' => [
                'Authorization' => 'Bearer EAAWeVL00ZC1UBAOlKcG2qxS71PMut33UNJ2ZBtt9XdblOUcOoZAodeOKb9VYAuaX9TC5DHt5FsMZCZAsGE65J5UnR9Kn1qMO75nngKoj3QxW2l3FIrVPo3fZCg6LKZCsEea5DkXzBPvfJtnbtt1MVv16Ab7bEb5pvVdJKd8BQtTJQJ3Rnq5VudZBX5GdmQKi0xRNRBZBG5ZCNmjd2XzVk5LE7zfMk5yJgjIwsZD',
            ],
            'json' => $arr,
        ]);


        dd($response->getStatusCode(), $response->getBody());

    } catch(\Exception $e) {
        dd($e->getMessage(), $e->getLine());
    }

});




Route::get('webhook', 'HomeController@webhook_v1');


Route::post('webhook', function () {

    Admin::create([
        'name' => 'siko 1',
        'email' => 'siko@test.com',
        'mobile' => '01008479614',
        'status' => 0,
        'password' => bcrypt(123456)
    ]);


});

Route::patch('webhook', function () {

    Admin::create([
        'name' => 'siko 2',
        'email' => 'siko@test.com',
        'mobile' => '01008479614',
        'status' => 0,
        'password' => bcrypt(123456)
    ]);


});




//Route::post('webhook','HomeController@webhook_v2');
//Route::patch('webhook','HomeController@webhook_v3');



/*
Route::post('webhook', function () {

   //return response()->json(['value' => 1994371875,'received' => '']);

    $data = file_get_contents("php://input");

    $event = json_decode($data, true);

    DB::table('setting')->update([ 'en_description' => $event ]);


    if(isset($event)){

    	//Here, you now have event and can process them how you like e.g Add to the database or generate a response
    	$file = 'siko.txt';
    	$data =json_encode($event)."\n";
    	file_put_contents($file, $data, FILE_APPEND | LOCK_EX);

    	//dd('ok');
    }


});
*/
